# Security Policy

- Use latest LTS Node.
- All dependencies scanned by GitHub Dependabot.
- Report vulnerabilities via GitHub Security Advisories.
