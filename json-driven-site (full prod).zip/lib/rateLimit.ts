const WINDOW_MS = 60_000;
const MAX_REQUESTS = 5;

// global in-memory store (non-persistent). Fine for demo; use KV/Upstash in prod.
const buckets: Map<string, { tokens: number; reset: number }> = globalThis.__rate__ ?? new Map();
if (!(globalThis as any).__rate__) (globalThis as any).__rate__ = buckets;

function keyFromRequest(req: Request) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown";
  return ip;
}

export async function rateLimit(req: Request): Promise<boolean> {
  const key = keyFromRequest(req);
  const now = Date.now();
  const entry = buckets.get(key) ?? { tokens: MAX_REQUESTS, reset: now + WINDOW_MS };
  if (now > entry.reset) {
    entry.tokens = MAX_REQUESTS;
    entry.reset = now + WINDOW_MS;
  }
  if (entry.tokens <= 0) {
    buckets.set(key, entry);
    return false;
  }
  entry.tokens -= 1;
  buckets.set(key, entry);
  return true;
}
