import { loadSite } from "./content";

export function baseMetadata() {
  const site = loadSite();
  const title = site.page.header.logo.text || "Site";
  const description = site.page.hero?.leftSection?.title ?? "Site";
  const url = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  return {
    title,
    description,
    metadataBase: new URL(url),
    openGraph: {
      title,
      description,
      url,
      siteName: title,
      images: [{ url: `/api/og?title=${encodeURIComponent(title)}` }],
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [`/api/og?title=${encodeURIComponent(title)}`],
    },
    alternates: {
      canonical: url,
    },
  };
}
