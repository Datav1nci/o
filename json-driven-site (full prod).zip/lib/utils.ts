import { type ClassValue } from "clsx";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function styleFromJson(style?: {
  backgroundColor?: string;
  textColor?: string;
  borderRadius?: string;
  shape?: "circle";
}) {
  const s: React.CSSProperties = {};
  if (!style) return s;
  if (style.backgroundColor) s.backgroundColor = style.backgroundColor;
  if (style.textColor) s.color = style.textColor;
  if (style.borderRadius) s.borderRadius = style.borderRadius as any;
  if (style.shape === "circle") s.borderRadius = "9999px";
  return s;
}
