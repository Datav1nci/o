import siteData from "@/content/site.json";
import { SiteSchema, type Site } from "./types";

export function loadSite(): Site {
  const parsed = SiteSchema.safeParse(siteData);
  if (!parsed.success) {
    if (process.env.NODE_ENV !== "production") {
      console.error(parsed.error.flatten());
      // Show a dev-friendly JSON error
    }
    throw new Error("Invalid site.json");
  }
  return parsed.data;
}
