import { z } from "zod";

const style = z.object({
  backgroundColor: z.string().optional(),
  textColor: z.string().optional(),
  borderRadius: z.string().optional(),
  shape: z.enum(["circle"]).optional(),
  icon: z.string().optional(),
});

const link = z.object({
  label: z.string(),
  url: z.string().default("#"),
});

export const SiteSchema = z.object({
  page: z.object({
    header: z.object({
      logo: z.object({
        text: z.string(),
        subtext: z.string().optional(),
        position: z.enum(["left","right"]).default("left"),
      }),
      nav: z.array(z.object({
        label: z.string(),
        active: z.boolean().optional(),
        url: z.string().optional(),
      })),
      ctaButton: z.object({
        label: z.string(),
        position: z.enum(["left","right"]).default("right"),
        style,
      }),
    }),
    hero: z.object({
      background: z.string(),
      leftSection: z.object({
        title: z.string(),
        buttons: z.array(z.object({ label: z.string(), style })),
        footerNote: z.object({
          text: z.string(),
          icon: z.string().optional(),
        }),
      }),
      rightSection: z.object({
        image: z.string(),
        overlayTexts: z.array(z.object({
          text: z.string(),
          style,
        })).optional(),
        badges: z.array(z.object({
          text: z.string(),
          style,
          position: z.enum(["bottomRight","bottomLeft","topRight","topLeft"]).default("bottomRight"),
        })).optional(),
      }),
    }),
    sections: z.array(z.object({
      id: z.string(),
      title: z.string(),
      layout: z.string().optional(),
      text: z.string().optional(),
      image: z.string().optional(),
      items: z.array(z.object({
        icon: z.string(),
        title: z.string(),
        description: z.string(),
        link: link.optional(),
      })).optional(),
      ctaButton: z.object({
        label: z.string(),
        style,
      }).optional(),
    })),
    footer: z.object({
      contactForm: z.object({
        title: z.string(),
        fields: z.array(z.object({
          type: z.enum(["text","email","textarea"]),
          name: z.string(),
          placeholder: z.string().optional(),
        })),
        ctaButton: z.object({
          label: z.string(),
          style,
        }),
      }),
      logo: z.object({
        text: z.string(),
        subtext: z.string().optional(),
      }),
      links: z.array(link),
      social: z.array(z.object({
        platform: z.string(),
        icon: z.string(),
        url: z.string(),
      })),
      copyright: z.string(),
    }),
  }),
});

export type Site = z.infer<typeof SiteSchema>;
