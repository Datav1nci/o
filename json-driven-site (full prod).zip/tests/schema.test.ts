import { describe, it, expect } from "vitest";
import { SiteSchema } from "@/lib/types";
import sample from "@/content/site.json";

describe("SiteSchema", () => {
  it("accepts valid sample json", () => {
    const res = SiteSchema.safeParse(sample);
    expect(res.success).toBe(true);
  });

  it("rejects invalid json", () => {
    const res = SiteSchema.safeParse({});
    expect(res.success).toBe(false);
  });
});
