import { render, screen } from "@testing-library/react";
import React from "react";
import Hero from "@/app/(site)/components/Hero";

describe("Hero", () => {
  it("renders hero title", () => {
    render(React.createElement(Hero));
    expect(screen.getByRole("heading")).toBeInTheDocument();
  });
});
