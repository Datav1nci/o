import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

test("homepage loads and has nav", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("banner")).toBeVisible();
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();

  const accessibilityScanResults = await new AxeBuilder({ page }).analyze();
  expect(accessibilityScanResults.violations).toEqual([]);
});

test("contact form submits", async ({ page }) => {
  await page.goto("/");
  await page.getByLabel("nom").fill("Jean");
  await page.getByLabel("email").fill("jean@example.com");
  await page.getByLabel("message").fill("Bonjour!");
  await page.getByRole("button", { name: "Envoyer" }).click();
  await expect(page.getByRole("status")).toBeVisible();
});
