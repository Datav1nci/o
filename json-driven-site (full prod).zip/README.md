# JSON-Driven Ö HOME Site (Next.js 14, TypeScript, Tailwind, shadcn/ui)

Production-ready template that renders a landing site **entirely from JSON** with strong Zod validation, tests, CI, and instant Vercel deploy.

## Tech
- Next.js (App Router) + TypeScript + React 18
- Tailwind CSS (+ forms & typography), shadcn/ui (Button), lucide-react
- React Hook Form + Zod
- SEO (Metadata API, /api/og, robots, sitemap), Vercel Analytics + cookie consent
- Accessibility: skip link, aria labels, axe check in E2E
- Security headers via Next + vercel.json
- Performance: optimized images, minimal JS, server components

## Getting Started
```bash
pnpm i
cp .env.example .env.local
pnpm dev
```

Open http://localhost:3000.

## Use *your* JSON
Replace the content in `content/site.json` with your JSON (the structure must match `lib/types.ts`). The UI will render **exactly** from that JSON.
On invalid JSON, the app throws with details in dev.

## Deploy to Vercel
1. Push to a GitHub repo.
2. Add GitHub secrets: `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`.
3. CI will deploy previews on PRs and production on `main`.

## Tests
- Unit: `pnpm test`
- E2E: `pnpm e2e` (runs Playwright + axe)

## File Map (key paths)
See repository tree in the chat message.
