import { ImageResponse } from "@vercel/og";
import { loadSite } from "@/lib/content";

export const runtime = "edge";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const title = searchParams.get("title") ?? loadSite().page.header.logo.text;
  return new ImageResponse(
    (
      <div
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          textAlign: "left",
          alignItems: "center",
          justifyContent: "flex-start",
          backgroundColor: "#0ea5e9",
          color: "white",
          padding: 64,
          fontSize: 64,
          fontWeight: 800,
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>{title}</div>
          <div style={{ fontSize: 28, fontWeight: 500 }}>Généré par Next.js + @vercel/og</div>
        </div>
      </div>
    ),
    { width: 1200, height: 630 }
  );
}
