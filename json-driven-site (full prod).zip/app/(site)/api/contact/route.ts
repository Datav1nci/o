import { NextResponse } from "next/server";
import { rateLimit } from "@/lib/rateLimit";
import { z } from "zod";
import { loadSite } from "@/lib/content";

export const runtime = "edge";

export async function POST(req: Request) {
  const ok = await rateLimit(req);
  if (!ok) return NextResponse.json({ ok:false, error:"Too many requests" }, { status: 429 });

  const site = loadSite();
  const fields = site.page.footer.contactForm.fields;
  const schema = z.object(
    fields.reduce((acc: any, f) => {
      if (f.type === "email") acc[f.name] = z.string().email();
      else acc[f.name] = z.string().min(1);
      return acc;
    }, {} as Record<string, any>)
  );
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok:false, error:"Invalid data" }, { status: 400 });
  }

  // In production: send to email provider (Resend, Postmark) or CRM
  // For demo: log only
  console.log("Contact form submission", parsed.data);

  return NextResponse.json({ ok: true });
}
