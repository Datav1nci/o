import "./../../styles/globals.css";
import type { Metadata } from "next";
import { baseMetadata } from "@/lib/seo";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import { Analytics } from "@vercel/analytics/react";

export const metadata: Metadata = baseMetadata();

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr-CA">
      <body className="antialiased">
        <a href="#content" className="skip-to-content">Aller au contenu</a>
        <Header />
        <main id="content">{children}</main>
        <Footer />
        <CookieBanner />
        <Analytics />
      </body>
    </html>
  );
}
