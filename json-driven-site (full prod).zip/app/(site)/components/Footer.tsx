"use client";

import * as React from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { loadSite } from "@/lib/content";
import { Button } from "./Button";

const site = loadSite();
const formSchema = z.object(
  site.page.footer.contactForm.fields.reduce((acc: any, f) => {
    if (f.type === "email") acc[f.name] = z.string().email();
    else acc[f.name] = z.string().min(1);
    return acc;
  }, {} as Record<string, z.ZodTypeAny>)
);

type FormData = z.infer<typeof formSchema>;

export default function Footer() {
  const footer = site.page.footer;
  const [status, setStatus] = React.useState<null | { ok: boolean; msg: string }>(null);

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data: FormData) => {
    setStatus(null);
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const j = await res.json().catch(() => ({ ok: false }));
    if (j.ok) {
      setStatus({ ok: true, msg: "Message envoyé. Merci!" });
      reset();
    } else {
      setStatus({ ok: false, msg: j.error ?? "Erreur. Réessayez." });
    }
  };

  return (
    <footer className="border-t border-gray-200 bg-white" aria-label="Pied de page">
      <div className="mx-auto max-w-6xl px-4 py-14 grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <div className="text-xl font-extrabold">{footer.logo.text}</div>
          {footer.logo.subtext && <div className="text-sm text-gray-500">{footer.logo.subtext}</div>}
          <ul className="mt-6 space-y-2">
            {footer.links.map((l, i) => (
              <li key={i}><Link href={l.url} className="text-sm text-gray-700 hover:underline">{l.label}</Link></li>
            ))}
          </ul>
          <div className="mt-6 flex gap-3">
            {footer.social.map((s, i) => (
              <Link key={i} href={s.url} aria-label={s.platform} className="text-gray-600 hover:text-gray-900">{s.platform}</Link>
            ))}
          </div>
        </div>

        <div className="md:col-span-2">
          <h3 className="text-lg font-semibold">{footer.contactForm.title}</h3>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-4 grid grid-cols-1 gap-4">
            {footer.contactForm.fields.map((f, i) => (
              <div key={i}>
                {f.type !== "textarea" ? (
                  <input
                    aria-label={f.name}
                    placeholder={f.placeholder}
                    className="w-full rounded-md border px-3 py-2 focus-visible:outline-none focus-visible:ring-2"
                    type={f.type}
                    {...register(f.name as any)}
                  />
                ) : (
                  <textarea
                    aria-label={f.name}
                    placeholder={f.placeholder}
                    className="w-full rounded-md border px-3 py-2 min-h-28 focus-visible:outline-none focus-visible:ring-2"
                    {...register(f.name as any)}
                  />
                )}
                {errors[f.name as keyof FormData] && (
                  <p className="text-sm text-red-600 mt-1">Champ invalide</p>
                )}
              </div>
            ))}
            <div>
              <Button
                type="submit"
                aria-label={footer.contactForm.ctaButton.label}
                label={footer.contactForm.ctaButton.label}
                style={footer.contactForm.ctaButton.style}
                disabled={isSubmitting}
              />
            </div>
            {status && (
              <div
                role="status"
                className={`rounded-md px-3 py-2 text-sm ${status.ok ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}
              >
                {status.msg}
              </div>
            )}
          </form>
        </div>
      </div>
      <div className="text-center text-sm text-gray-500 border-t py-4">{footer.copyright}</div>
    </footer>
  );
}
