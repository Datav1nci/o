import * as React from "react";
import { styleFromJson } from "@/lib/utils";

export function Badge({ text, style }: { text: string; style?: any }) {
  return (
    <span
      className="inline-flex items-center px-3 py-1 text-xs font-semibold shadow-sm"
      style={{
        ...styleFromJson(style),
      }}
      aria-label={text}
    >
      {text}
    </span>
  );
}
