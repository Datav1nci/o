"use client";

import * as React from "react";
import * as Icons from "lucide-react";

type IconName = keyof typeof Icons;

export function Icon({
  name,
  className,
  label,
}: {
  name: string;
  className?: string;
  label?: string;
}) {
  const LucideIcon = (Icons as any)[name as IconName] ?? Icons.HelpCircle;
  return <LucideIcon className={className} aria-label={label} aria-hidden={!label} />;
}
