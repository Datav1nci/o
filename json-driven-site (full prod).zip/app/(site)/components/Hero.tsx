import Image from "next/image";
import * as React from "react";
import { loadSite } from "@/lib/content";
import { Button } from "./Button";
import { Badge } from "./Badge";
import { styleFromJson } from "@/lib/utils";

export default function Hero() {
  const hero = loadSite().page.hero;

  return (
    <section
      className="relative"
      style={{ background: hero.background }}
      aria-label="Héros"
    >
      <div className="mx-auto max-w-6xl px-4 py-16 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
        <div className="space-y-6">
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
            {hero.leftSection.title}
          </h1>
          <div className="flex gap-3">
            {hero.leftSection.buttons.map((b, i) => (
              <Button key={i} label={b.label} style={b.style} />
            ))}
          </div>
          <p className="text-gray-600 flex items-center gap-2">
            <span role="img" aria-label="Canada">🇨🇦</span> {hero.leftSection.footerNote.text}
          </p>
        </div>

        <div className="relative">
          <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden bg-white/60 shadow">
            <Image
              src={hero.rightSection.image}
              alt="Appareil de filtration"
              fill
              className="object-contain"
              sizes="(min-width: 768px) 600px, 100vw"
              priority
            />
            {/* Overlay texts */}
            <div className="absolute top-3 left-3 flex flex-col gap-2">
              {hero.rightSection.overlayTexts?.map((o, i) => (
                <span
                  key={i}
                  className="px-3 py-1 text-xs font-medium"
                  style={styleFromJson(o.style)}
                >
                  {o.text}
                </span>
              ))}
            </div>

            {/* Badges positioned */}
            {hero.rightSection.badges?.map((b, i) => {
              const pos = b.position;
              const map: Record<string, string> = {
                bottomRight: "bottom-3 right-3",
                bottomLeft: "bottom-3 left-3",
                topRight: "top-3 right-3",
                topLeft: "top-3 left-3",
              };
              return (
                <div key={i} className={`absolute ${map[pos]}`}>
                  <Badge text={b.text} style={b.style} />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
