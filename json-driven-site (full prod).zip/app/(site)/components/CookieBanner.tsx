"use client";

import * as React from "react";

export default function CookieBanner() {
  const [visible, setVisible] = React.useState(false);
  React.useEffect(() => {
    const v = localStorage.getItem("cookie-consent");
    if (!v) setVisible(true);
  }, []);
  if (!visible) return null;
  return (
    <div className="fixed bottom-4 inset-x-0 px-4">
      <div className="mx-auto max-w-3xl rounded-xl border bg-white shadow p-4 flex items-center justify-between gap-4">
        <p className="text-sm text-gray-700">
          Nous utilisons des cookies pour analyser le trafic (Vercel Analytics). En continuant, vous acceptez.
        </p>
        <button
          className="text-sm font-medium px-3 py-1 rounded-md bg-sky-600 text-white"
          onClick={() => {
            localStorage.setItem("cookie-consent", "1");
            setVisible(false);
          }}
          aria-label="Accepter les cookies"
        >
          D’accord
        </button>
      </div>
    </div>
  );
}
