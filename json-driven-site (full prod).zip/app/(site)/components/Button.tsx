"use client";

import * as React from "react";
import { Button as UIButton } from "@/components/ui/button";
import { styleFromJson, cn } from "@/lib/utils";

export function Button({
  label,
  style,
  className,
  ...props
}: {
  label: string;
  style?: any;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <UIButton
      className={cn("rounded-2xl", className)}
      style={{ ...styleFromJson(style) }}
      {...props}
    >
      <span>{label}</span>
    </UIButton>
  );
}
