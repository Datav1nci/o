import Link from "next/link";
import Image from "next/image";
import * as React from "react";
import { loadSite } from "@/lib/content";
import { Button } from "./Button";
import { styleFromJson, cn } from "@/lib/utils";

export default function Header() {
  const site = loadSite();
  const header = site.page.header;

  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur border-b border-gray-200">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center gap-4">
        <Link href="/" className="flex items-center gap-3" aria-label="Accueil">
          <div className="font-extrabold text-xl tracking-tight">{header.logo.text}</div>
          {header.logo.subtext && (
            <div className="text-xs text-gray-500">{header.logo.subtext}</div>
          )}
        </Link>
        <nav aria-label="Navigation principale" className="ml-auto hidden md:flex gap-6">
          {header.nav.map((item, i) => (
            <Link
              key={i}
              href={item.url ?? "#"}
              className={cn(
                "text-sm font-medium hover:text-sky-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 rounded",
                item.active ? "text-sky-700" : "text-gray-700"
              )}
              aria-current={item.active ? "page" : undefined}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="ml-4">
          <Button
            label={header.ctaButton.label}
            style={header.ctaButton.style}
            aria-label={header.ctaButton.label}
          />
        </div>
      </div>
    </header>
  );
}
