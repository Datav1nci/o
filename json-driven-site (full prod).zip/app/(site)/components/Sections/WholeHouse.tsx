import Image from "next/image";
import * as React from "react";
import { Button } from "../Button";

export default function GenericSection({
  id,
  title,
  text,
  image,
  ctaButton,
}: {
  id: string;
  title: string;
  text?: string;
  image?: string;
  ctaButton?: { label: string; style?: any };
}) {
  return (
    <section id={id} className="mx-auto max-w-6xl px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-3xl font-bold">{title}</h2>
          {text && <p className="mt-4 text-gray-700">{text}</p>}
          {ctaButton && (
            <div className="mt-6">
              <Button label={ctaButton.label} style={ctaButton.style} />
            </div>
          )}
        </div>
        {image && (
          <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden bg-gray-50">
            <Image src={image} alt={title} fill className="object-contain" sizes="(min-width: 768px) 600px, 100vw" />
          </div>
        )}
      </div>
    </section>
  );
}
