import Link from "next/link";
import * as React from "react";
import { styleFromJson } from "@/lib/utils";
import { Icon } from "../Icon";

export default function Problems({
  title,
  items = [],
}: {
  title: string;
  items: { icon: string; title: string; description: string; link?: { label: string; url: string } }[];
}) {
  return (
    <section id="problems" className="mx-auto max-w-6xl px-4 py-16">
      <h2 className="text-3xl font-bold mb-8">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((it, i) => (
          <div key={i} className="rounded-2xl border p-5 shadow-sm bg-white">
            <Icon name={it.icon} className="w-6 h-6 text-sky-700" label={it.title} />
            <h3 className="mt-3 font-semibold text-lg">{it.title}</h3>
            <p className="text-gray-600 text-sm mt-1">{it.description}</p>
            {it.link && (
              <Link
                href={it.link.url}
                className="inline-flex mt-4 text-sm font-medium text-sky-700 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 rounded"
                aria-label={it.link.label}
              >
                {it.link.label}
              </Link>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
