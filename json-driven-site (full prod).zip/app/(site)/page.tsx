import Hero from "./components/Hero";
import Problems from "./components/Sections/Problems";
import WholeHouse from "./components/Sections/WholeHouse";
import DrinkingWater from "./components/Sections/DrinkingWater";
import Techniques from "./components/Sections/Techniques";
import Distribution from "./components/Sections/Distribution";
import { loadSite } from "@/lib/content";

export default function Page() {
  const site = loadSite();
  const sections = site.page.sections;

  return (
    <>
      <Hero />
      {sections.map((s) => {
        switch (s.id) {
          case "problems":
            return <Problems key={s.id} title={s.title} items={s.items ?? []} />;
          case "whole-house":
            return <WholeHouse key={s.id} id="whole-house" title={s.title} text={s.text} image={s.image} ctaButton={s.ctaButton} />;
          case "drinking":
            return <DrinkingWater key={s.id} id="drinking" title={s.title} text={s.text} image={s.image} ctaButton={s.ctaButton} />;
          case "techniques":
            return <Techniques key={s.id} id="techniques" title={s.title} text={s.text} image={s.image} ctaButton={s.ctaButton} />;
          case "distribution":
            return <Distribution key={s.id} id="distribution" title={s.title} text={s.text} image={s.image} ctaButton={s.ctaButton} />;
          default:
            return null;
        }
      })}
    </>
  );
}
